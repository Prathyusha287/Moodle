const AdminProfile =() =>{
 return (
    <>
    <h1> Admin profile</h1>
    </>
 )
}
export default AdminProfile;