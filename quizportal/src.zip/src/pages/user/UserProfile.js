import React,{useState,useEffect} from "react";
import SidebarUser from "../../components/SidebarUser";
import {Table} from "react-bootstrap"
import Image from "react-bootstrap/Image"
import { useParams } from "react-router-dom";
import axios from "axios"
const UserProfile = () =>{
    const { username } = useParams();
     const [user ,setUser] =useState([]);
    
     const getUser = async () =>{
        try{
            await axios.get(`http://localhost:8084/users/${username}`)
            .then((res) =>{
              console.log(res.data)
              setUser(res.data)
            })
          }catch(err){
            console.log(err)
          
        }
      }


      useEffect(()=>{
        getUser();
      })

    return (
        <div className="userProfilePage__container">
          <div className="userProfilePage__sidebar">
            <SidebarUser />
          </div>
          {user && (
            <div className="userProfilePage__content">
              <Image
                className="userProfilePage__content--profilePic"
                width="20%"
                height="20%"
                roundedCircle
                src="images/user.png"
              />
    
              <Table bordered className="userProfilePage__content--table">
                <tbody>
                  <tr>
                    <td>Name</td>
                    <td>{`${user.name} `}</td>
                  </tr>
                  <tr>
                    <td>Username</td>
                    <td>{user.username}</td>
                  </tr>
                  <tr>
                    <td>Phone</td>
                    <td>{user.email}</td>
                  </tr>
                  <tr>
                    <td>Role</td>
                    <td>{user.role}</td>
                  </tr>
                </tbody>
              </Table>
            </div>
          )}
        </div>
      );
   
}
export default UserProfile;