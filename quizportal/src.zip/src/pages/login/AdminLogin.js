import { useNavigate } from "react-router-dom"
import Loginnav from "../../navbar/Loginnav"
import React,{useState} from 'react'
import axios from 'axios'

const AdminLogin=()=>{
    const navigate=useNavigate();
    const [data,setData]=useState(
        {
            email:"",
            password:""
        }
    )
    function handleChange(event){
        event.preventDefault()
        setData({
            ...data,
            [event.target.name]:event.target.value
        })
    }
    function handleClick(event){
        event.preventDefault()
        if(data.email===""||data.password===""){
            alert("enter all fields")
        }
        else{
            axios.post("http://localhost:8084/login",data,
            {
                headers:{
                    "Context-Type":"application/json",
                },
            })
            .then((res)=>
            {
                console.log(res.data);
                if(res.data==="admin"){
                    
                    localStorage.setItem("admin",res.data)
                    navigate("/")
                   
                }
                else if(res.data==="Not"){
                    alert("Invalid credentials")
                }
            })
        }
    }
    return(
        <div>
            <Loginnav/>
            <form className="form-control container mt-5 p-4">
                <h1>Admin Login</h1>
                <div className="d-flex mb-2">
                    <label className="col-md-3">Email</label>
                    <input className="col-md-6" onChange={handleChange} type="email" name="email" value={data.email} placeholder="enter email"></input>
                </div>
                <div className="d-flex mb-2">
                    <label className="col-md-3" >password</label>
                    <input className="col-md-6" onChange={handleChange} type="password" name="password" value={data.password} placeholder="enter passsword"></input>
                </div>
                <button onClick={handleClick} className="btn btn-primary mt-2">Login</button>
            </form>

        </div>
    )
}
export default AdminLogin;