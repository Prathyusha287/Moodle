import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "react-bootstrap";
const Home = () =>{
    
    const navigate = useNavigate();
    return(
       <>
       
       <div className="home_container">
        <div  className="home_content">
        <section>
                <div>
                    <h1>Home</h1> 
                </div>
            </section>
            <Button onClick={() => navigate("/login")}>Login</Button>
            <Button onClick={() => navigate("/register")}>Register</Button>

        </div>
               
       </div>
       </>
    )
}

export default Home;