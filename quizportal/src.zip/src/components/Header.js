import React ,{useEffect,useState}from 'react';
import {Navbar,Nav,Container} from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';
import {LinkContainer} from 'react-router-bootstrap'

const Header = () => {
    const navigate = useNavigate();
    const [isLoggedIn,setIsLoggedIn] = useState(false);
    const[user,setUser] = useState(null);

    let profilePageUrl = "";

    const logoutHandler = () => {
        setIsLoggedIn(false);
        localStorage.clear();
        navigate("/login");
    };

    useEffect(() =>{
        if(localStorage.getItem('jwtToken')){
            setIsLoggedIn(true);
            const storedUser = JSON.parse(localStorage.getItem("user"));
            setUser(storedUser);
            storedUser.roles.map((r) =>{
                if(r.role ==="admin"){
                    profilePageUrl = "/adminProfile";
                } else{
                    profilePageUrl="/";
                }

            });
        }
    },[navigate]);


    return (
     <header>
        <Navbar bg= "dark" variant="dark" expand = "lg" collapseOnSelect>
            <Container>
                <Navbar.Brand>Moodle</Navbar.Brand>

                <Navbar.Toggle aria-controls="responsive-navbar-nav"/>
                <Navbar.Collapse id = "responsive-navbar-nav">
                    <Nav className = "justify-content-end flex-grow-1 pe-3">
                        {isLoggedIn?(
                            <Nav.Link>{user.name}</Nav.Link>
                        ):(
                            <LinkContainer to="/">
                                <Nav.Link>Login</Nav.Link>
                            </LinkContainer>
                        )}

                        {isLoggedIn ?(
                            <LinkContainer to = "/">
                                <Nav.Link onClick={logoutHandler}>Logout</Nav.Link>
                            </LinkContainer>
                        ):(
                            <LinkContainer to ="/register">
                                <Nav.Link>Register</Nav.Link>
                            </LinkContainer>
                        )}
                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
     </header>
    );

};

export default Header;
